# Divisione Mance — Terrazza Duomo 21

App PWA per la gestione e divisione delle mance per turno.

## Deploy

```bash
cd mance-pwa
firebase deploy --only hosting:terrazzaduomo21-mance-terrazza
```

## Aggiornare il codice

```bash
cd mance-pwa
git add .
git commit -m "descrizione modifica"
git push
firebase deploy --only hosting:terrazzaduomo21-mance-terrazza
```

## URL
https://terrazzaduomo21-mance-terrazza.web.app

## Funzionalità
- Divisione mance per turno (19–23 e 23–04)
- Settori: Cassa, Cucina, Bar, Sala, Lavaggio (1.5), Sicurezza, Bagni
- Assenti con contratto → quota in cassetta
- Arrotondamento al multiplo di €5 → resto in cassetta
- Rapporto giornaliero e mensile
- Cassetta protetta da PIN (2626)
